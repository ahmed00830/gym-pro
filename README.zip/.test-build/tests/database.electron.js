"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
const strict_1 = __importDefault(require("node:assert/strict"));
const node_fs_1 = require("node:fs");
const node_os_1 = require("node:os");
const node_path_1 = require("node:path");
const connection_1 = require("../src/main/database/connection");
const date_time_1 = require("../src/main/database/date-time");
const GymProDatabase_1 = require("../src/main/database/GymProDatabase");
const migrate_1 = require("../src/main/database/migrate");
const migrations_1 = require("../src/main/database/migrations");
const TEST_ROOT = (0, node_path_1.join)((0, node_os_1.tmpdir)(), 'gympro-database-foundation-tests');
const TEST_DB_PATH = (0, node_path_1.join)(TEST_ROOT, 'persistence', 'gym-pro.db');
const PHASE = process.argv.includes('verify') ? 'verify' : 'seed';
const APPLICATION_TABLES = [
    'activity_logs',
    'attendance',
    'expenses',
    'expense_categories',
    'members',
    'member_number_sequence',
    'membership_plans',
    'notifications',
    'payments',
    'settings',
    'subscriptions',
    'users'
];
let passed = 0;
let failed = 0;
function runTest(name, test) {
    try {
        test();
        passed += 1;
        console.log(`PASS  ${name}`);
    }
    catch (error) {
        failed += 1;
        console.error(`FAIL  ${name}`);
        console.error(error instanceof Error ? error.stack : error);
    }
}
function getTableNames(database) {
    return database
        .prepare(`SELECT name
         FROM sqlite_master
         WHERE type = 'table' AND name NOT LIKE 'sqlite_%'
         ORDER BY name`)
        .all().map((row) => row.name);
}
function getCount(database, table) {
    const allowedTables = new Set([
        ...APPLICATION_TABLES,
        'schema_migrations'
    ]);
    if (!allowedTables.has(table)) {
        throw new Error(`Invalid test table: ${table}`);
    }
    return database.prepare(`SELECT COUNT(*) AS count FROM ${table}`).get().count;
}
function isoDateRegex(value) {
    return /^\d{4}-\d{2}-\d{2}$/.test(value);
}
function utcTimestampRegex(value) {
    return /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(value);
}
function seedPhase() {
    (0, node_fs_1.rmSync)(TEST_ROOT, { recursive: true, force: true });
    (0, node_fs_1.mkdirSync)(TEST_ROOT, { recursive: true });
    let service = null;
    let inspection = null;
    const closeResources = () => {
        if (inspection)
            inspection.close();
        if (service)
            service.close();
    };
    try {
        runTest('fresh database reports pending, then initializes', () => {
            service = new GymProDatabase_1.GymProDatabase(TEST_DB_PATH);
            const before = service.getInitializationStatus();
            strict_1.default.equal(before.state, 'pending');
            strict_1.default.equal(before.initialized, false);
            strict_1.default.equal(before.schemaVersion, 0);
            strict_1.default.equal(before.targetSchemaVersion, 9);
            strict_1.default.equal(before.pendingMigrationCount, 9);
            const after = service.initialize();
            strict_1.default.equal(after.state, 'ready');
            strict_1.default.equal(after.initialized, true);
            strict_1.default.equal(after.schemaVersion, 9);
            strict_1.default.equal(after.pendingMigrationCount, 0);
            strict_1.default.equal(after.appliedMigrations.length, 9);
            strict_1.default.equal(after.error, null);
            strict_1.default.equal((0, node_fs_1.existsSync)(TEST_DB_PATH), true);
            const health = service.healthCheck();
            strict_1.default.equal(health.ok, true);
            strict_1.default.equal(health.integrityCheck, 'ok');
            strict_1.default.equal(health.foreignKeysEnabled, true);
            strict_1.default.equal(health.foreignKeyViolations, 0);
            strict_1.default.equal(health.journalMode, 'wal');
            const info = service.getInfo();
            strict_1.default.equal(info.engine, 'SQLite');
            strict_1.default.equal(info.fileName, 'gym-pro.db');
            strict_1.default.equal(info.filePath, TEST_DB_PATH);
            strict_1.default.equal(info.schemaVersion, 9);
            strict_1.default.equal(info.applicationTableCount, 13);
            strict_1.default.equal(info.foreignKeysEnabled, true);
            strict_1.default.equal(info.journalMode, 'wal');
            strict_1.default.match(info.sqliteVersion, /^3\.\d+\.\d+$/);
            strict_1.default.ok(info.sizeBytes > 0);
            strict_1.default.ok(info.pageSize > 0);
            strict_1.default.ok(info.initializedAt && utcTimestampRegex(info.initializedAt));
        });
        runTest('all required tables, indexes, and migration history exist', () => {
            strict_1.default.ok(service);
            inspection = (0, connection_1.createDatabaseConnection)(TEST_DB_PATH);
            const tables = getTableNames(inspection);
            for (const table of APPLICATION_TABLES) {
                strict_1.default.ok(tables.includes(table), `Missing table: ${table}`);
            }
            strict_1.default.ok(tables.includes('schema_migrations'));
            const history = (0, migrate_1.listAppliedMigrations)(inspection);
            strict_1.default.deepEqual(history.map((migration) => ({
                version: migration.version,
                name: migration.name
            })), [
                { version: 1, name: 'core_schema' },
                { version: 2, name: 'system_tables' },
                { version: 3, name: 'member_photo' },
                { version: 4, name: 'subscription_freezes' },
                { version: 5, name: 'attendance_unique_member_date' },
                { version: 6, name: 'member_numbers' },
                { version: 7, name: 'subscription_history_snapshots' },
                { version: 8, name: 'expenses_hardening' },
                { version: 9, name: 'expense_categories' }
            ]);
            strict_1.default.ok(history.every((migration) => utcTimestampRegex(migration.appliedAt)));
            const foreignKeys = inspection.pragma('foreign_keys', {
                simple: true
            });
            strict_1.default.equal(foreignKeys, 1);
        });
        runTest('migrations apply stepwise in order and are idempotent', () => {
            const stepPath = (0, node_path_1.join)(TEST_ROOT, 'stepwise', 'stepwise.db');
            const stepDatabase = (0, connection_1.createDatabaseConnection)(stepPath);
            try {
                const first = (0, migrate_1.runMigrations)(stepDatabase, migrations_1.MIGRATIONS.slice(0, 1));
                strict_1.default.equal(first.fromVersion, 0);
                strict_1.default.equal(first.toVersion, 1);
                strict_1.default.deepEqual(first.appliedMigrations.map((migration) => migration.version), [1]);
                const afterFirst = getTableNames(stepDatabase);
                strict_1.default.ok(afterFirst.includes('members'));
                strict_1.default.ok(afterFirst.includes('subscriptions'));
                strict_1.default.ok(afterFirst.includes('expenses'));
                strict_1.default.equal(afterFirst.includes('users'), false);
                strict_1.default.equal(afterFirst.includes('notifications'), false);
                const second = (0, migrate_1.runMigrations)(stepDatabase, migrations_1.MIGRATIONS);
                strict_1.default.equal(second.fromVersion, 1);
                strict_1.default.equal(second.toVersion, 9);
                strict_1.default.deepEqual(second.appliedMigrations.map((migration) => migration.version), [2, 3, 4, 5, 6, 7, 8, 9]);
                const afterSecond = getTableNames(stepDatabase);
                for (const table of APPLICATION_TABLES) {
                    strict_1.default.ok(afterSecond.includes(table), `Missing table: ${table}`);
                }
                const noOp = (0, migrate_1.runMigrations)(stepDatabase, migrations_1.MIGRATIONS);
                strict_1.default.equal(noOp.fromVersion, 9);
                strict_1.default.equal(noOp.toVersion, 9);
                strict_1.default.deepEqual(noOp.appliedMigrations, []);
            }
            finally {
                stepDatabase.close();
            }
        });
        runTest('member codes are generated, unique, and never reused', () => {
            strict_1.default.ok(inspection);
            const insertMember = inspection.prepare(`INSERT INTO members (full_name, phone, notes)
         VALUES (?, ?, ?)`);
            const marker = insertMember.run('Persistence Marker', '01000000000', 'persistence-marker');
            const second = insertMember.run('Second Member', '01111111111', null);
            strict_1.default.equal(Number(marker.lastInsertRowid), 1);
            strict_1.default.equal(Number(second.lastInsertRowid), 2);
            const firstCodes = inspection
                .prepare('SELECT member_code FROM members ORDER BY id ASC')
                .all();
            strict_1.default.deepEqual(firstCodes.map((row) => row.member_code), ['GYM-000001', 'GYM-000002']);
            const uniqueCodes = inspection
                .prepare('SELECT COUNT(DISTINCT member_code) AS count FROM members')
                .get().count;
            strict_1.default.equal(uniqueCodes, firstCodes.length);
            const indexes = inspection.prepare("PRAGMA index_list('members')").all();
            const uniqueIndexes = indexes.filter((index) => index.unique === 1);
            const indexColumns = (indexName) => inspection
                .prepare(`PRAGMA index_info(${JSON.stringify(indexName)})`)
                .all().map((column) => column.name);
            const codeIndex = uniqueIndexes.find((index) => JSON.stringify(indexColumns(index.name)) ===
                JSON.stringify(['member_code']));
            strict_1.default.ok(codeIndex, 'member_code must have a UNIQUE index');
            const numberIndex = uniqueIndexes.find((index) => JSON.stringify(indexColumns(index.name)) ===
                JSON.stringify(['member_number']));
            strict_1.default.ok(numberIndex, 'member_number must have a UNIQUE index');
            strict_1.default.throws(() => inspection
                .prepare(`INSERT INTO members (member_code, full_name)
               VALUES (?, ?)`)
                .run('GYM-000001', 'Forbidden Duplicate'), /generated column/i);
            inspection.prepare('DELETE FROM members WHERE id = ?').run(2);
            insertMember.run('Third Member', '01222222222', null);
            const thirdCode = inspection
                .prepare('SELECT member_code FROM members WHERE id = ?')
                .get(3).member_code;
            strict_1.default.equal(thirdCode, 'GYM-000003');
            strict_1.default.notEqual(thirdCode, 'GYM-000002');
        });
        runTest('foreign keys and financial history protections are enforced', () => {
            strict_1.default.ok(inspection);
            const today = (0, date_time_1.toLocalIsoDate)();
            const endDate = (0, date_time_1.addDaysToLocalIsoDate)(today, 30);
            const planId = Number(inspection
                .prepare(`INSERT INTO membership_plans
               (name, duration_days, price, description)
             VALUES (?, ?, ?, ?)`)
                .run('Monthly Standard', 30, 500, 'Integration test plan')
                .lastInsertRowid);
            const subscriptionId = Number(inspection
                .prepare(`INSERT INTO subscriptions
               (member_id, plan_id, start_date, end_date, price,
                discount, final_price, status)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)`)
                .run(1, planId, today, endDate, 500, 50, 450, 'active')
                .lastInsertRowid);
            const paymentId = Number(inspection
                .prepare(`INSERT INTO payments
               (member_id, subscription_id, amount, payment_method,
                payment_date, notes)
             VALUES (?, ?, ?, ?, ?, ?)`)
                .run(1, subscriptionId, 450, 'cash', today, 'Persistence payment')
                .lastInsertRowid);
            inspection
                .prepare('INSERT INTO attendance (member_id) VALUES (?)')
                .run(1);
            inspection
                .prepare(`INSERT INTO expenses
             (description, category, amount, payment_method)
           VALUES (?, ?, ?, ?)`)
                .run('Test expense', 'operations', 75, 'cash');
            const insertSubscription = inspection.prepare(`INSERT INTO subscriptions
           (member_id, plan_id, start_date, end_date, price,
            discount, final_price, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`);
            strict_1.default.throws(() => insertSubscription.run(999_999, planId, today, endDate, 500, 0, 500, 'active'), /FOREIGN KEY constraint failed/);
            strict_1.default.throws(() => inspection
                .prepare(`INSERT INTO payments
                 (member_id, subscription_id, amount, payment_method)
               VALUES (?, ?, ?, ?)`)
                .run(1, 999_999, 10, 'cash'), /FOREIGN KEY constraint failed/);
            strict_1.default.throws(() => inspection
                .prepare('DELETE FROM members WHERE id = ?')
                .run(1), /FOREIGN KEY constraint failed/);
            strict_1.default.throws(() => inspection
                .prepare('DELETE FROM membership_plans WHERE id = ?')
                .run(planId), /FOREIGN KEY constraint failed/);
            strict_1.default.throws(() => inspection
                .prepare('DELETE FROM subscriptions WHERE id = ?')
                .run(subscriptionId), /Subscription history cannot be deleted/);
            strict_1.default.throws(() => inspection
                .prepare('DELETE FROM payments WHERE id = ?')
                .run(paymentId), /Payment history cannot be deleted/);
            const violations = inspection.pragma('foreign_key_check');
            strict_1.default.equal(violations.length, 0);
        });
        runTest('support tables work and activity logs preserve anonymous history', () => {
            strict_1.default.ok(inspection);
            const userId = Number(inspection
                .prepare(`INSERT INTO users (username, password_hash, full_name, role)
             VALUES (?, ?, ?, ?)`)
                .run('test.operator', '$argon2id$integration-test-placeholder', 'Test Operator', 'admin').lastInsertRowid);
            inspection
                .prepare(`INSERT INTO settings ("key", value, value_type)
           VALUES (?, ?, ?)`)
                .run('locale', 'ar', 'string');
            inspection
                .prepare(`INSERT INTO notifications
             (type, title, message, severity, related_entity_type,
              related_entity_id)
           VALUES (?, ?, ?, ?, ?, ?)`)
                .run('test', 'Integration test', 'Notification storage works.', 'info', 'member', 1);
            const logId = Number(inspection
                .prepare(`INSERT INTO activity_logs
               (user_id, action, entity_type, entity_id, details)
             VALUES (?, ?, ?, ?, ?)`)
                .run(userId, 'test.action', 'member', 1, '{"test":true}')
                .lastInsertRowid);
            inspection.prepare('DELETE FROM users WHERE id = ?').run(userId);
            const log = inspection
                .prepare('SELECT user_id FROM activity_logs WHERE id = ?')
                .get(logId);
            strict_1.default.equal(log.user_id, null);
            strict_1.default.equal(getCount(inspection, 'settings'), 1);
            strict_1.default.equal(getCount(inspection, 'notifications'), 1);
            strict_1.default.equal(getCount(inspection, 'activity_logs'), 1);
        });
        runTest('workspace snapshot reports stored records without writing data', () => {
            strict_1.default.ok(service);
            strict_1.default.ok(inspection);
            const membersBefore = getCount(inspection, 'members');
            const snapshot = service.getWorkspaceSnapshot();
            strict_1.default.match(snapshot.generatedAt, /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/);
            strict_1.default.equal(snapshot.totals.totalRevenue, 450);
            strict_1.default.equal(snapshot.totals.revenueThisMonth, 450);
            strict_1.default.equal(snapshot.totals.totalExpenses, 75);
            strict_1.default.equal(snapshot.totals.expensesThisMonth, 75);
            strict_1.default.equal(snapshot.totals.totalPayments, 1);
            strict_1.default.equal(snapshot.totals.totalExpenseEntries, 1);
            strict_1.default.equal(snapshot.totals.activeMembers, 2);
            strict_1.default.equal(snapshot.totals.totalMembers, 2);
            strict_1.default.equal(snapshot.totals.newRegistrations, 2);
            strict_1.default.equal(snapshot.totals.todayAttendance, 1);
            strict_1.default.equal(snapshot.totals.attendanceThisMonth, 1);
            strict_1.default.equal(snapshot.totals.totalAttendance, 1);
            strict_1.default.equal(snapshot.totals.membershipRenewals, 0);
            strict_1.default.equal(snapshot.totals.totalRenewals, 0);
            strict_1.default.equal(snapshot.totals.expiringMemberships, 0);
            strict_1.default.equal(snapshot.totals.activeSubscriptions, 1);
            strict_1.default.equal(snapshot.totals.totalSubscriptions, 1);
            strict_1.default.equal(snapshot.totals.totalPlans, 1);
            strict_1.default.equal(snapshot.totals.activePlans, 1);
            strict_1.default.equal(snapshot.totals.unreadNotifications, 1);
            strict_1.default.equal(snapshot.members.length, 2);
            strict_1.default.equal(snapshot.members[0].memberCode, 'GYM-000003');
            strict_1.default.equal(snapshot.memberStatusCounts.length, 6);
            strict_1.default.equal(snapshot.memberStatusCounts.find((entry) => entry.status === 'active')
                ?.count, 2);
            strict_1.default.equal(snapshot.plans.length, 1);
            strict_1.default.equal(snapshot.plans[0].activeSubscribers, 1);
            strict_1.default.equal(snapshot.subscriptions.length, 1);
            strict_1.default.equal(snapshot.subscriptions[0].memberName, 'Persistence Marker');
            strict_1.default.equal(snapshot.subscriptions[0].planName, 'Monthly Standard');
            strict_1.default.equal(snapshot.renewals.length, 0);
            strict_1.default.equal(snapshot.payments.length, 1);
            strict_1.default.equal(snapshot.payments[0].amount, 450);
            strict_1.default.equal(snapshot.payments[0].paymentMethod, 'cash');
            strict_1.default.equal(snapshot.attendance.length, 1);
            strict_1.default.equal(snapshot.attendance[0].memberCode, 'GYM-000001');
            strict_1.default.equal(snapshot.expenses.length, 1);
            strict_1.default.equal(snapshot.expenses[0].category, 'operations');
            strict_1.default.equal(snapshot.notifications.length, 1);
            strict_1.default.equal(snapshot.notifications[0].isRead, false);
            strict_1.default.equal(snapshot.settings.length, 1);
            strict_1.default.equal(snapshot.settings[0].value, 'ar');
            strict_1.default.equal(snapshot.attendanceSeries.length, 7);
            strict_1.default.equal(snapshot.attendanceSeries[6].attendance, 1);
            strict_1.default.equal(snapshot.attendanceSeries[6].registrations, 2);
            strict_1.default.equal(snapshot.monthlyReport.length, 6);
            strict_1.default.equal(snapshot.monthlyReport[5].month, (0, date_time_1.toLocalIsoDate)().slice(0, 7));
            strict_1.default.equal(snapshot.monthlyReport[5].revenue, 450);
            strict_1.default.equal(snapshot.monthlyReport[5].expenses, 75);
            strict_1.default.equal(snapshot.monthlyReport[5].newMembers, 2);
            strict_1.default.deepEqual(snapshot.paymentMethods, [
                { method: 'cash', count: 1, total: 450 }
            ]);
            strict_1.default.deepEqual(snapshot.expenseCategories, [
                { category: 'operations', count: 1, total: 75 }
            ]);
            strict_1.default.equal(getCount(inspection, 'members'), membersBefore);
        });
        runTest('related writes roll back atomically on failure', () => {
            strict_1.default.ok(inspection);
            const expensesBefore = getCount(inspection, 'expenses');
            const plansBefore = getCount(inspection, 'membership_plans');
            const failingTransaction = inspection.transaction(() => {
                inspection
                    .prepare(`INSERT INTO expenses
               (description, category, amount, payment_method)
             VALUES (?, ?, ?, ?)`)
                    .run('Rolled back expense', 'test', 1, 'cash');
                inspection
                    .prepare(`INSERT INTO membership_plans
               (name, duration_days, price)
             VALUES (?, ?, ?)`)
                    .run('Rolled back plan', 1, 1);
                throw new Error('forced rollback');
            });
            strict_1.default.throws(failingTransaction, /forced rollback/);
            strict_1.default.equal(getCount(inspection, 'expenses'), expensesBefore);
            strict_1.default.equal(getCount(inspection, 'membership_plans'), plansBefore);
        });
        runTest('local business dates and UTC audit timestamps are consistent', () => {
            strict_1.default.ok(inspection);
            strict_1.default.equal((0, date_time_1.toLocalIsoDate)(new Date(2026, 10, 12, 23, 30)), '2026-11-12');
            strict_1.default.equal((0, date_time_1.addDaysToLocalIsoDate)('2026-11-12', 30), '2026-12-12');
            const attendance = inspection
                .prepare(`SELECT check_in_date, check_in_time, created_at
           FROM attendance
           ORDER BY id ASC
           LIMIT 1`)
                .get();
            strict_1.default.ok(isoDateRegex(attendance.check_in_date));
            strict_1.default.match(attendance.check_in_time, /^\d{2}:\d{2}:\d{2}$/);
            strict_1.default.ok(utcTimestampRegex(attendance.created_at));
            const today = inspection
                .prepare(`SELECT check_in_date = date('now', 'localtime') AS is_today
           FROM attendance
           ORDER BY id ASC
           LIMIT 1`)
                .get();
            strict_1.default.equal(today.is_today, 1);
            const marker = inspection
                .prepare(`SELECT registration_date, created_at
           FROM members WHERE id = 1`)
                .get();
            strict_1.default.ok(isoDateRegex(marker.registration_date));
            strict_1.default.ok(utcTimestampRegex(marker.created_at));
        });
        runTest('initialized database is ready for a restart', () => {
            strict_1.default.equal((0, node_fs_1.existsSync)(TEST_DB_PATH), true);
            strict_1.default.ok(service);
            strict_1.default.equal(service.getInitializationStatus().state, 'ready');
            strict_1.default.ok((0, node_fs_1.statSync)(TEST_DB_PATH).size > 0);
        });
    }
    finally {
        closeResources();
    }
    memberNumberSeedPhase();
    subscriptionLifecycleSeedPhase();
    expenseLifecycleSeedPhase();
}
function subscriptionLifecycleSeedPhase() {
    const lifecycleDbPath = (0, node_path_1.join)(TEST_ROOT, 'lifecycle', 'lifecycle.db');
    (0, node_fs_1.mkdirSync)((0, node_path_1.dirname)(lifecycleDbPath), { recursive: true });
    let service = null;
    let inspection = null;
    const closeResources = () => {
        if (inspection)
            inspection.close();
        if (service)
            service.close();
    };
    const memberInput = (fullName, phone) => ({
        fullName,
        phone,
        secondaryPhone: null,
        address: null,
        gender: null,
        dateOfBirth: null,
        emergencyContact: null,
        notes: null,
        registrationDate: (0, date_time_1.toLocalIsoDate)(),
        photoData: null
    });
    try {
        runTest('subscription lifecycle: plans, full payment, history, renewals, revenue', () => {
            service = new GymProDatabase_1.GymProDatabase(lifecycleDbPath);
            const status = service.initialize();
            strict_1.default.equal(status.state, 'ready');
            strict_1.default.equal(status.schemaVersion, 9);
            const today = (0, date_time_1.toLocalIsoDate)();
            const halfMonth = service.createPlan({
                name: 'Half Month',
                durationDays: 15,
                price: 400,
                description: null,
                isActive: true
            });
            strict_1.default.equal(halfMonth.durationDays, 15);
            const member = service.createMember(memberInput('Lifecycle Member', '01000000031'));
            strict_1.default.equal(member.memberNumber, 1);
            strict_1.default.equal(service.getWorkspaceSnapshot().subscriptions.length, 0);
            strict_1.default.throws(() => service.createSubscription({
                memberId: member.id,
                planId: halfMonth.id,
                startDate: today,
                endDate: (0, date_time_1.addDaysToLocalIsoDate)(today, 15),
                price: halfMonth.price,
                discount: 0,
                paymentAmount: 150,
                paymentMethod: 'cash',
                paymentDate: today,
                paymentNotes: null,
                subscriptionNotes: null
            }), /Full payment is required/);
            strict_1.default.equal(service.getWorkspaceSnapshot().subscriptions.length, 0);
            const subscription = service.createSubscription({
                memberId: member.id,
                planId: halfMonth.id,
                startDate: today,
                endDate: (0, date_time_1.addDaysToLocalIsoDate)(today, 15),
                price: halfMonth.price,
                discount: 0,
                paymentAmount: halfMonth.price,
                paymentMethod: 'card',
                paymentDate: today,
                paymentNotes: null,
                subscriptionNotes: null
            });
            strict_1.default.equal(subscription.status, 'active');
            strict_1.default.equal(subscription.planName, 'Half Month');
            strict_1.default.equal(subscription.durationDays, 15);
            strict_1.default.equal(subscription.memberNumber, member.memberNumber);
            strict_1.default.equal(subscription.finalPrice, 400);
            strict_1.default.equal(subscription.paidAmount, 400);
            service.updatePlan(halfMonth.id, {
                name: 'Renamed Plan',
                durationDays: 30,
                price: 550,
                description: null,
                isActive: true
            });
            const afterEdit = service
                .getWorkspaceSnapshot()
                .subscriptions.find((entry) => entry.id === subscription.id);
            strict_1.default.equal(afterEdit?.planName, 'Half Month');
            strict_1.default.equal(afterEdit?.durationDays, 15);
            strict_1.default.equal(afterEdit?.price, 400);
            strict_1.default.equal(afterEdit?.finalPrice, 400);
            const renewed = service.quickRenewSubscription({
                memberId: member.id,
                planId: halfMonth.id,
                paymentMethod: 'card',
                paymentDate: today,
                startDate: null,
                notes: null
            });
            strict_1.default.equal(renewed.status, 'active');
            strict_1.default.equal(renewed.finalPrice, 550);
            strict_1.default.equal(renewed.planName, 'Renamed Plan');
            strict_1.default.equal(renewed.durationDays, 30);
            const monthStart = `${today.slice(0, 7)}-01`;
            const todayReport = service.getRangeReport(today, today);
            strict_1.default.equal(todayReport.collectedRevenue, 950);
            strict_1.default.equal(todayReport.subscriptionPayments, 2);
            strict_1.default.equal(todayReport.newSubscriptions, 2);
            strict_1.default.equal(todayReport.renewals, 1);
            strict_1.default.equal(todayReport.expenses, 0);
            strict_1.default.equal(todayReport.netRevenue, 950);
            const monthReport = service.getRangeReport(monthStart, today);
            strict_1.default.equal(monthReport.collectedRevenue, 950);
            strict_1.default.equal(monthReport.newSubscriptions, 2);
            strict_1.default.equal(monthReport.renewals, 1);
            const emptyReport = service.getRangeReport((0, date_time_1.addDaysToLocalIsoDate)(today, -400), (0, date_time_1.addDaysToLocalIsoDate)(today, -390));
            strict_1.default.equal(emptyReport.collectedRevenue, 0);
            strict_1.default.equal(emptyReport.subscriptionPayments, 0);
            strict_1.default.throws(() => service.getRangeReport('2026-13-40', today), /invalid date/);
            strict_1.default.throws(() => service.getRangeReport(today, '2020-01-01'), /after its end/);
            const expenseConnection = (0, connection_1.createDatabaseConnection)(lifecycleDbPath);
            expenseConnection
                .prepare(`INSERT INTO expenses (description, category, amount, payment_method)
           VALUES (?, ?, ?, ?)`)
                .run('Range smoke expense', 'operations', 75, 'cash');
            expenseConnection.close();
            const withExpense = service.getRangeReport(today, today);
            strict_1.default.equal(withExpense.expenses, 75);
            strict_1.default.equal(withExpense.netRevenue, 875);
            const snapshot = service.getWorkspaceSnapshot();
            strict_1.default.equal(snapshot.subscriptions.length, 2);
            strict_1.default.equal(snapshot.payments.length, 2);
            strict_1.default.equal(snapshot.renewals.length, 1);
            strict_1.default.equal(snapshot.renewals[0].id, renewed.id);
            strict_1.default.equal(snapshot.renewals[0].planName, 'Renamed Plan');
            strict_1.default.equal(snapshot.totals.totalRevenue, 400 + 550);
            strict_1.default.equal(snapshot.totals.revenueThisMonth, 950);
            strict_1.default.equal(snapshot.totals.revenueToday, 950);
            inspection = (0, connection_1.createDatabaseConnection)(lifecycleDbPath);
            const stored = inspection
                .prepare('SELECT plan_name, duration_days FROM subscriptions ORDER BY id ASC')
                .all();
            strict_1.default.deepEqual(stored.map((row) => [row.plan_name, row.duration_days]), [
                ['Half Month', 15],
                ['Renamed Plan', 30]
            ]);
        });
    }
    finally {
        closeResources();
    }
}
function memberNumberSeedPhase() {
    const memberNumberDbPath = (0, node_path_1.join)(TEST_ROOT, 'member-numbers', 'member-numbers.db');
    (0, node_fs_1.mkdirSync)((0, node_path_1.dirname)(memberNumberDbPath), { recursive: true });
    let service = null;
    let inspection = null;
    const closeResources = () => {
        if (inspection)
            inspection.close();
        if (service)
            service.close();
    };
    const memberInput = (fullName, phone) => ({
        fullName,
        phone,
        secondaryPhone: null,
        address: null,
        gender: null,
        dateOfBirth: null,
        emergencyContact: null,
        notes: null,
        registrationDate: (0, date_time_1.toLocalIsoDate)(),
        photoData: null
    });
    try {
        runTest('member numbers are sequential, permanent, and unique', () => {
            service = new GymProDatabase_1.GymProDatabase(memberNumberDbPath);
            const status = service.initialize();
            strict_1.default.equal(status.state, 'ready');
            strict_1.default.equal(status.schemaVersion, 9);
            inspection = (0, connection_1.createDatabaseConnection)(memberNumberDbPath);
            const plan = service.createPlan({
                name: 'Number Test Plan',
                durationDays: 30,
                price: 500,
                description: null,
                isActive: true
            });
            const first = service.createMember(memberInput('First Member', '01000000001'));
            const second = service.createMember(memberInput('Second Member', '01000000002'));
            strict_1.default.equal(first.memberNumber, 1);
            strict_1.default.equal(second.memberNumber, 2);
            const renamed = service.updateMember(first.id, memberInput('First Member Renamed', '01000000001'));
            strict_1.default.equal(renamed.memberNumber, 1);
            const quick = service.quickRegisterMember({
                fullName: 'Quick Member',
                phone: '01000000003',
                planId: plan.id,
                startDate: (0, date_time_1.toLocalIsoDate)(),
                paymentMethod: 'cash',
                paymentDate: (0, date_time_1.toLocalIsoDate)(),
                notes: null
            });
            strict_1.default.equal(quick.member.memberNumber, 3);
            strict_1.default.throws(() => inspection
                .prepare(`INSERT INTO members (full_name, member_number)
               VALUES (?, ?)`)
                .run('Duplicate Number', 1), /UNIQUE constraint failed/);
            const sequence = inspection
                .prepare('SELECT last_number FROM member_number_sequence WHERE id = 1')
                .get();
            strict_1.default.equal(sequence.last_number, 3);
        });
        runTest('attendance requires an active subscription and blocks duplicates', () => {
            strict_1.default.ok(service);
            const today = (0, date_time_1.toLocalIsoDate)();
            const plan = service.createPlan({
                name: 'Attendance Test Plan',
                durationDays: 30,
                price: 400,
                description: null,
                isActive: true
            });
            const activeMember = service.createMember(memberInput('Active Attendee', '01000000011'));
            const activeSubscription = service.createSubscription({
                memberId: activeMember.id,
                planId: plan.id,
                startDate: today,
                endDate: (0, date_time_1.addDaysToLocalIsoDate)(today, 30),
                price: plan.price,
                discount: 0,
                paymentAmount: plan.price,
                paymentMethod: 'cash',
                paymentDate: today,
                paymentNotes: null,
                subscriptionNotes: null
            });
            strict_1.default.equal(activeSubscription.status, 'active');
            const record = service.registerAttendance(activeMember.id);
            strict_1.default.equal(record.memberNumber, activeMember.memberNumber);
            strict_1.default.equal(record.checkInDate, today);
            strict_1.default.throws(() => service.registerAttendance(activeMember.id), /already registered/i);
            service.freezeSubscription(activeSubscription.id, today, null, 'Test freeze');
            strict_1.default.throws(() => service.registerAttendance(activeMember.id), /frozen/i);
            const expiredMember = service.createMember(memberInput('Expired Attendee', '01000000012'));
            service.createSubscription({
                memberId: expiredMember.id,
                planId: plan.id,
                startDate: (0, date_time_1.addDaysToLocalIsoDate)(today, -40),
                endDate: (0, date_time_1.addDaysToLocalIsoDate)(today, -10),
                price: plan.price,
                discount: 0,
                paymentAmount: plan.price,
                paymentMethod: 'cash',
                paymentDate: today,
                paymentNotes: null,
                subscriptionNotes: null
            });
            strict_1.default.throws(() => service.registerAttendance(expiredMember.id), /expired/i);
            const noSubscriptionMember = service.createMember(memberInput('No Subscription Attendee', '01000000013'));
            strict_1.default.throws(() => service.registerAttendance(noSubscriptionMember.id), /No active subscription/);
            strict_1.default.throws(() => inspection
                .prepare(`INSERT INTO attendance (member_id, check_in_date)
               VALUES (?, ?)`)
                .run(activeMember.id, today), /UNIQUE constraint failed/);
        });
    }
    finally {
        closeResources();
    }
}
function expenseLifecycleSeedPhase() {
    const expensesDbPath = (0, node_path_1.join)(TEST_ROOT, 'expenses', 'expenses.db');
    (0, node_fs_1.mkdirSync)((0, node_path_1.dirname)(expensesDbPath), { recursive: true });
    let service = null;
    let inspection = null;
    const closeResources = () => {
        if (inspection)
            inspection.close();
        if (service)
            service.close();
    };
    const memberInput = (fullName, phone) => ({
        fullName,
        phone,
        secondaryPhone: null,
        address: null,
        gender: null,
        dateOfBirth: null,
        emergencyContact: null,
        notes: null,
        registrationDate: (0, date_time_1.toLocalIsoDate)(),
        photoData: null
    });
    const expenseInput = (overrides = {}) => ({
        description: 'Utility bill',
        category: 'electricity',
        amount: 120.5,
        paymentMethod: 'cash',
        expenseDate: (0, date_time_1.toLocalIsoDate)(),
        expenseTime: null,
        recordedBy: 'Ahmed',
        notes: null,
        ...overrides
    });
    try {
        runTest('expense ledger: create, edit, archive, audit, cash register', () => {
            service = new GymProDatabase_1.GymProDatabase(expensesDbPath);
            const status = service.initialize();
            strict_1.default.equal(status.state, 'ready');
            strict_1.default.equal(status.schemaVersion, 9);
            const today = (0, date_time_1.toLocalIsoDate)();
            const plan = service.createPlan({
                name: 'Expense Test Plan',
                durationDays: 30,
                price: 400,
                description: null,
                isActive: true
            });
            const member = service.createMember(memberInput('Expense Attendee', '01000000081'));
            service.createSubscription({
                memberId: member.id,
                planId: plan.id,
                startDate: today,
                endDate: (0, date_time_1.addDaysToLocalIsoDate)(today, 30),
                price: plan.price,
                discount: 0,
                paymentAmount: plan.price,
                paymentMethod: 'cash',
                paymentDate: today,
                paymentNotes: null,
                subscriptionNotes: null
            });
            let snapshot = service.getWorkspaceSnapshot();
            strict_1.default.equal(snapshot.totals.totalExpenses, 0);
            strict_1.default.equal(snapshot.totals.totalRevenue, 400);
            const expense = service.createExpense(expenseInput());
            strict_1.default.equal(expense.status, 'active');
            strict_1.default.equal(expense.recordedBy, 'Ahmed');
            strict_1.default.equal(expense.amount, 120.5);
            strict_1.default.equal(expense.category, 'electricity');
            strict_1.default.ok(expense.expenseTime);
            snapshot = service.getWorkspaceSnapshot();
            strict_1.default.equal(snapshot.totals.totalExpenses, 120.5);
            strict_1.default.equal(snapshot.totals.expensesToday, 120.5);
            const updated = service.updateExpense(expense.id, expenseInput({ amount: 220, recordedBy: 'Mostafa' }));
            strict_1.default.equal(updated.amount, 220);
            strict_1.default.equal(updated.recordedBy, 'Mostafa');
            snapshot = service.getWorkspaceSnapshot();
            strict_1.default.equal(snapshot.totals.totalExpenses, 220);
            strict_1.default.throws(() => service.createExpense(expenseInput({ category: 'spaceships' })), /category/i);
            const archived = service.archiveExpense(expense.id);
            strict_1.default.equal(archived.status, 'archived');
            snapshot = service.getWorkspaceSnapshot();
            strict_1.default.equal(snapshot.totals.totalExpenses, 0);
            strict_1.default.equal(snapshot.expenses.find((entry) => entry.id === expense.id)?.status, 'archived');
            strict_1.default.throws(() => service.archiveExpense(expense.id), /archived/i);
            strict_1.default.throws(() => service.updateExpense(expense.id, expenseInput()), /archived/i);
            const created = service.createExpenseCategory({
                key: 'laundry',
                nameAr: 'مغسلة',
                nameEn: 'Laundry'
            });
            strict_1.default.equal(created.key, 'laundry');
            const laundryExpense = service.createExpense(expenseInput({
                description: 'Laundry supplies',
                category: 'laundry',
                amount: 30,
                recordedBy: null
            }));
            strict_1.default.equal(laundryExpense.category, 'laundry');
            service.setExpenseCategoryActive('laundry', false);
            strict_1.default.throws(() => service.createExpense(expenseInput({ category: 'laundry' })), /category/i);
            snapshot = service.getWorkspaceSnapshot();
            strict_1.default.equal(snapshot.expenseCatalog.length, 9);
            strict_1.default.equal(snapshot.expenseCatalog.find((entry) => entry.key === 'laundry')?.isActive, false);
            strict_1.default.equal(snapshot.totals.totalExpenses, 30);
            inspection = (0, connection_1.createDatabaseConnection)(expensesDbPath);
            const logs = inspection
                .prepare('SELECT action, entity_type FROM activity_logs ORDER BY id ASC')
                .all();
            const actions = new Set(logs.map((row) => row.action));
            strict_1.default.equal(actions.has('expense.create'), true);
            strict_1.default.equal(actions.has('expense.update'), true);
            strict_1.default.equal(actions.has('expense.archive'), true);
            strict_1.default.equal(actions.has('expense.category.create'), true);
            strict_1.default.equal(actions.has('expense.category.set_active'), true);
            strict_1.default.ok(logs.every((row) => row.entity_type.startsWith('expense')));
        });
    }
    finally {
        closeResources();
    }
}
function verifyPersistencePhase() {
    let service = null;
    let inspection = null;
    const closeResources = () => {
        if (inspection)
            inspection.close();
        if (service)
            service.close();
    };
    try {
        runTest('database persists across a fresh Electron process', () => {
            strict_1.default.equal((0, node_fs_1.existsSync)(TEST_DB_PATH), true);
            service = new GymProDatabase_1.GymProDatabase(TEST_DB_PATH);
            const status = service.initialize();
            strict_1.default.equal(status.state, 'ready');
            strict_1.default.equal(status.schemaVersion, 9);
            strict_1.default.equal(status.appliedMigrations.length, 9);
            strict_1.default.equal(service.healthCheck().ok, true);
            inspection = (0, connection_1.createDatabaseConnection)(TEST_DB_PATH);
            const marker = inspection
                .prepare(`SELECT member_code, full_name, notes
           FROM members WHERE id = 1`)
                .get();
            strict_1.default.deepEqual(marker, {
                member_code: 'GYM-000001',
                full_name: 'Persistence Marker',
                notes: 'persistence-marker'
            });
            const subscription = inspection
                .prepare('SELECT COUNT(*) AS count FROM subscriptions')
                .get();
            const payment = inspection
                .prepare('SELECT COUNT(*) AS count FROM payments')
                .get();
            const settings = inspection
                .prepare('SELECT COUNT(*) AS count FROM settings')
                .get();
            strict_1.default.equal(subscription.count, 1);
            strict_1.default.equal(payment.count, 1);
            strict_1.default.equal(settings.count, 1);
            strict_1.default.equal(inspection
                .prepare('SELECT COUNT(*) AS count FROM schema_migrations')
                .get().count, 9);
        });
        runTest('workspace snapshot remains available after a restart', () => {
            strict_1.default.ok(service);
            const snapshot = service.getWorkspaceSnapshot();
            strict_1.default.equal(snapshot.totals.totalRevenue, 450);
            strict_1.default.equal(snapshot.totals.activeMembers, 2);
            strict_1.default.equal(snapshot.totals.todayAttendance, 1);
            strict_1.default.equal(snapshot.members.length, 2);
            strict_1.default.equal(snapshot.plans.length, 1);
            strict_1.default.equal(snapshot.subscriptions.length, 1);
            strict_1.default.equal(snapshot.payments.length, 1);
            strict_1.default.equal(snapshot.attendance.length, 1);
            strict_1.default.equal(snapshot.notifications.length, 1);
            strict_1.default.equal(snapshot.settings.length, 1);
        });
        runTest('member numbers and attendance persist across a restart', () => {
            const memberNumberDbPath = (0, node_path_1.join)(TEST_ROOT, 'member-numbers', 'member-numbers.db');
            strict_1.default.equal((0, node_fs_1.existsSync)(memberNumberDbPath), true);
            const reopened = new GymProDatabase_1.GymProDatabase(memberNumberDbPath);
            strict_1.default.equal(reopened.initialize().state, 'ready');
            const inspection = (0, connection_1.createDatabaseConnection)(memberNumberDbPath);
            try {
                const numbers = inspection
                    .prepare('SELECT member_number FROM members ORDER BY member_number ASC')
                    .all();
                strict_1.default.deepEqual(numbers.map((row) => row.member_number), [1, 2, 3, 4, 5, 6]);
                const attendanceCount = inspection
                    .prepare('SELECT COUNT(*) AS count FROM attendance')
                    .get().count;
                strict_1.default.equal(attendanceCount, 1);
            }
            finally {
                inspection.close();
                reopened.close();
            }
        });
        runTest('expense ledger and audit trail persist across a restart', () => {
            const expensesDbPath = (0, node_path_1.join)(TEST_ROOT, 'expenses', 'expenses.db');
            strict_1.default.equal((0, node_fs_1.existsSync)(expensesDbPath), true);
            const reopened = new GymProDatabase_1.GymProDatabase(expensesDbPath);
            strict_1.default.equal(reopened.initialize().state, 'ready');
            const inspection = (0, connection_1.createDatabaseConnection)(expensesDbPath);
            try {
                const active = inspection
                    .prepare("SELECT COUNT(*) AS count FROM expenses WHERE status = 'active'")
                    .get().count;
                strict_1.default.equal(active, 1);
                const archived = inspection
                    .prepare("SELECT COUNT(*) AS count FROM expenses WHERE status = 'archived'")
                    .get().count;
                strict_1.default.equal(archived, 1);
                const logs = inspection
                    .prepare('SELECT COUNT(*) AS count FROM activity_logs')
                    .get().count;
                strict_1.default.ok(logs >= 4);
                const snapshot = reopened.getWorkspaceSnapshot();
                strict_1.default.equal(snapshot.totals.totalExpenses, 30);
                strict_1.default.equal(snapshot.totals.expensesToday, 30);
                strict_1.default.equal(snapshot.expenseCatalog.length, 9);
            }
            finally {
                inspection.close();
                reopened.close();
            }
        });
        runTest('range report persists after a restart', () => {
            const lifecycleDbPath = (0, node_path_1.join)(TEST_ROOT, 'lifecycle', 'lifecycle.db');
            strict_1.default.equal((0, node_fs_1.existsSync)(lifecycleDbPath), true);
            const reopened = new GymProDatabase_1.GymProDatabase(lifecycleDbPath);
            strict_1.default.equal(reopened.initialize().state, 'ready');
            try {
                const today = (0, date_time_1.toLocalIsoDate)();
                const report = reopened.getRangeReport(`${today.slice(0, 7)}-01`, today);
                strict_1.default.equal(report.collectedRevenue, 950);
                strict_1.default.equal(report.subscriptionPayments, 2);
                strict_1.default.equal(report.newSubscriptions, 2);
                strict_1.default.equal(report.renewals, 1);
                strict_1.default.equal(report.expenses, 75);
                strict_1.default.equal(report.netRevenue, 875);
            }
            finally {
                reopened.close();
            }
        });
        runTest('subscription history snapshots persist across a restart', () => {
            const lifecycleDbPath = (0, node_path_1.join)(TEST_ROOT, 'lifecycle', 'lifecycle.db');
            strict_1.default.equal((0, node_fs_1.existsSync)(lifecycleDbPath), true);
            const reopened = new GymProDatabase_1.GymProDatabase(lifecycleDbPath);
            strict_1.default.equal(reopened.initialize().state, 'ready');
            const inspection = (0, connection_1.createDatabaseConnection)(lifecycleDbPath);
            try {
                const rows = inspection
                    .prepare('SELECT plan_name, duration_days FROM subscriptions ORDER BY id ASC')
                    .all();
                strict_1.default.deepEqual(rows.map((row) => [row.plan_name, row.duration_days]), [
                    ['Half Month', 15],
                    ['Renamed Plan', 30]
                ]);
                const payments = inspection
                    .prepare('SELECT COUNT(*) AS count FROM payments')
                    .get().count;
                strict_1.default.equal(payments, 2);
            }
            finally {
                inspection.close();
                reopened.close();
            }
        });
    }
    finally {
        closeResources();
    }
    if (failed === 0) {
        (0, node_fs_1.rmSync)(TEST_ROOT, { recursive: true, force: true });
    }
}
function main() {
    console.log(`GYM PRO database integration tests — ${PHASE} phase`);
    console.log(`Test database: ${TEST_DB_PATH}`);
    if (PHASE === 'seed') {
        seedPhase();
    }
    else {
        verifyPersistencePhase();
    }
    console.log(`\n${passed} passed, ${failed} failed`);
    if (failed > 0 && (0, node_fs_1.existsSync)(TEST_ROOT)) {
        console.error(`Test artifacts retained for inspection: ${TEST_ROOT}`);
    }
    electron_1.app.exit(failed === 0 ? 0 : 1);
}
electron_1.app.disableHardwareAcceleration();
electron_1.app.commandLine.appendSwitch('disable-gpu');
electron_1.app
    .whenReady()
    .then(main)
    .catch((error) => {
    console.error(error instanceof Error ? error.stack : error);
    electron_1.app.exit(1);
});
//# sourceMappingURL=database.electron.js.map