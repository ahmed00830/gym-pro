"use strict";
/**
 * Database contracts shared by the Electron main process, preload bridge, and
 * renderer. These types deliberately contain no SQL, connection objects, or
 * filesystem handles.
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=database.js.map