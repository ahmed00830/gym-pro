"use strict";
/**
 * Read-only analytics and directory data shared by the main process and the
 * renderer. These types intentionally contain no SQL or database handles.
 *
 * The snapshot is a presentation-oriented view over the existing Phase 2
 * schema. It never writes data and never invents records: an empty database
 * produces zero totals and empty collections.
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=analytics.js.map