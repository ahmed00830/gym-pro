"use strict";
/**
 * Contract shared by the Electron main process, the sandboxed preload script,
 * and the React renderer. Keep this file free of Node.js and DOM APIs.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.IPC_CHANNELS = void 0;
exports.IPC_CHANNELS = {
    app: {
        getInfo: 'app:get-info'
    },
    database: {
        healthCheck: 'database:health-check',
        getInitializationStatus: 'database:get-initialization-status',
        getInfo: 'database:get-info'
    },
    analytics: {
        getSnapshot: 'analytics:get-snapshot',
        getRangeReport: 'analytics:get-range-report'
    },
    members: {
        create: 'members:create',
        update: 'members:update',
        delete: 'members:delete',
        quickRegister: 'members:quick-register'
    },
    plans: {
        create: 'plans:create',
        update: 'plans:update',
        setActive: 'plans:set-active'
    },
    subscriptions: {
        create: 'subscriptions:create',
        freeze: 'subscriptions:freeze',
        resume: 'subscriptions:resume',
        cancel: 'subscriptions:cancel',
        recordPayment: 'subscriptions:record-payment',
        quickRenew: 'subscriptions:quick-renew'
    },
    attendance: {
        register: 'attendance:register'
    },
    expenses: {
        create: 'expenses:create',
        update: 'expenses:update',
        archive: 'expenses:archive',
        createCategory: 'expenses:create-category',
        setCategoryActive: 'expenses:set-category-active',
        renameCategory: 'expenses:rename-category'
    }
};
//# sourceMappingURL=ipc.js.map