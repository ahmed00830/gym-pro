"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.readWorkspaceSnapshot = readWorkspaceSnapshot;
const date_time_1 = require("./date-time");
const MEMBER_STATUSES = [
    'active',
    'inactive',
    'frozen',
    'expired',
    'blocked',
    'archived'
];
function readCount(database, sql, ...params) {
    const row = database.prepare(sql).get(...params);
    return Number(row?.value ?? 0);
}
/**
 * Produces the read-only workspace snapshot from the existing schema.
 *
 * Everything here is derived from stored rows. An empty database yields zero
 * totals and empty collections — no demonstration records are inserted and no
 * statistics are invented.
 */
function readWorkspaceSnapshot(database) {
    const today = (0, date_time_1.toLocalIsoDate)();
    const monthStart = `${today.slice(0, 7)}-01`;
    const weekStart = (0, date_time_1.addDaysToLocalIsoDate)(today, -6);
    const weekEnd = today;
    const expiringEnd = (0, date_time_1.addDaysToLocalIsoDate)(today, 7);
    const todayDate = new Date();
    const reportMonths = [];
    for (let offset = 5; offset >= 0; offset -= 1) {
        const anchor = new Date(todayDate.getFullYear(), todayDate.getMonth() - offset, 1, 12, 0, 0, 0);
        reportMonths.push(`${anchor.getFullYear()}-${String(anchor.getMonth() + 1).padStart(2, '0')}`);
    }
    const reportStart = `${reportMonths[0]}-01`;
    const totals = {
        totalRevenue: readCount(database, 'SELECT COALESCE(SUM(amount), 0) AS value FROM payments'),
        revenueThisMonth: readCount(database, 'SELECT COALESCE(SUM(amount), 0) AS value FROM payments WHERE payment_date >= ?', monthStart),
        revenueToday: readCount(database, 'SELECT COALESCE(SUM(amount), 0) AS value FROM payments WHERE payment_date = ?', today),
        totalExpenses: readCount(database, "SELECT COALESCE(SUM(amount), 0) AS value FROM expenses WHERE status = 'active'"),
        expensesThisMonth: readCount(database, "SELECT COALESCE(SUM(amount), 0) AS value FROM expenses WHERE expense_date >= ? AND status = 'active'", monthStart),
        totalPayments: readCount(database, 'SELECT COUNT(*) AS value FROM payments'),
        totalExpenseEntries: readCount(database, "SELECT COUNT(*) AS value FROM expenses WHERE status = 'active'"),
        expensesToday: readCount(database, "SELECT COALESCE(SUM(amount), 0) AS value FROM expenses WHERE expense_date = ? AND status = 'active'", today),
        activeMembers: readCount(database, "SELECT COUNT(*) AS value FROM members WHERE status = 'active'"),
        totalMembers: readCount(database, 'SELECT COUNT(*) AS value FROM members'),
        newRegistrations: readCount(database, 'SELECT COUNT(*) AS value FROM members WHERE registration_date >= ?', monthStart),
        todayAttendance: readCount(database, 'SELECT COUNT(*) AS value FROM attendance WHERE check_in_date = ?', today),
        attendanceThisMonth: readCount(database, 'SELECT COUNT(*) AS value FROM attendance WHERE check_in_date >= ?', monthStart),
        totalAttendance: readCount(database, 'SELECT COUNT(*) AS value FROM attendance'),
        membershipRenewals: readCount(database, `SELECT COUNT(*) AS value
       FROM subscriptions s
       WHERE s.start_date >= ?
         AND EXISTS (
           SELECT 1
           FROM subscriptions earlier
           WHERE earlier.member_id = s.member_id
             AND (
               earlier.start_date < s.start_date
               OR (earlier.start_date = s.start_date AND earlier.id < s.id)
             )
         )`, monthStart),
        totalRenewals: readCount(database, `SELECT COUNT(*) AS value
       FROM subscriptions s
       WHERE EXISTS (
         SELECT 1
         FROM subscriptions earlier
         WHERE earlier.member_id = s.member_id
           AND (
             earlier.start_date < s.start_date
             OR (earlier.start_date = s.start_date AND earlier.id < s.id)
           )
       )`),
        expiringMemberships: readCount(database, `SELECT COUNT(DISTINCT member_id) AS value
       FROM subscriptions
       WHERE status = 'active'
         AND end_date >= ?
         AND end_date <= ?`, today, expiringEnd),
        activeSubscriptions: readCount(database, "SELECT COUNT(*) AS value FROM subscriptions WHERE status = 'active'"),
        totalSubscriptions: readCount(database, 'SELECT COUNT(*) AS value FROM subscriptions'),
        totalPlans: readCount(database, 'SELECT COUNT(*) AS value FROM membership_plans'),
        activePlans: readCount(database, 'SELECT COUNT(*) AS value FROM membership_plans WHERE is_active = 1'),
        unreadNotifications: readCount(database, 'SELECT COUNT(*) AS value FROM notifications WHERE is_read = 0')
    };
    const attendanceRows = database
        .prepare(`SELECT check_in_date AS date, COUNT(*) AS attendance
       FROM attendance
       WHERE check_in_date BETWEEN ? AND ?
       GROUP BY check_in_date`)
        .all(weekStart, weekEnd);
    const registrationRows = database
        .prepare(`SELECT registration_date AS date, COUNT(*) AS registrations
       FROM members
       WHERE registration_date BETWEEN ? AND ?
       GROUP BY registration_date`)
        .all(weekStart, weekEnd);
    const attendanceByDate = new Map(attendanceRows.map((row) => [row.date, Number(row.attendance)]));
    const registrationsByDate = new Map(registrationRows.map((row) => [row.date, Number(row.registrations)]));
    const attendanceSeries = [];
    for (let offset = 0; offset < 7; offset += 1) {
        const date = (0, date_time_1.addDaysToLocalIsoDate)(weekStart, offset);
        attendanceSeries.push({
            date,
            attendance: attendanceByDate.get(date) ?? 0,
            registrations: registrationsByDate.get(date) ?? 0
        });
    }
    const members = database
        .prepare(`SELECT id, member_code, member_number, full_name, phone, secondary_phone, address,
              gender, date_of_birth, registration_date, emergency_contact,
              notes, status, photo_data, created_at, updated_at
       FROM members
       ORDER BY registration_date DESC, id DESC`)
        .all();
    const statusCountRows = database
        .prepare(`SELECT status, COUNT(*) AS count
       FROM members
       GROUP BY status`)
        .all();
    const statusCounts = new Map(statusCountRows.map((row) => [row.status, Number(row.count)]));
    const memberStatusCounts = MEMBER_STATUSES.map((status) => ({
        status,
        count: statusCounts.get(status) ?? 0
    }));
    const planRows = database
        .prepare(`SELECT p.id, p.name, p.duration_days, p.price, p.description, p.is_active,
              (
                SELECT COUNT(*)
                FROM subscriptions s
                WHERE s.plan_id = p.id AND s.status = 'active'
              ) AS active_subscribers
       FROM membership_plans p
       ORDER BY p.is_active DESC, p.price ASC, p.id ASC`)
        .all();
    const subscriptionRows = database
        .prepare(`SELECT s.id, s.member_id, m.member_number, m.member_code, m.full_name AS member_name,
              s.plan_id, COALESCE(s.plan_name, p.name) AS plan_name,
              COALESCE(s.duration_days, p.duration_days) AS duration_days,
              s.start_date, s.end_date,
              s.price, s.discount, s.final_price, s.status,
              s.freeze_start_date, s.freeze_end_date, s.freeze_reason
       FROM subscriptions s
       JOIN members m ON m.id = s.member_id
       JOIN membership_plans p ON p.id = s.plan_id
       ORDER BY s.start_date DESC, s.id DESC`)
        .all();
    const renewalRows = database
        .prepare(`WITH ranked AS (
         SELECT s.*,
                ROW_NUMBER() OVER (
                  PARTITION BY s.member_id
                  ORDER BY s.start_date ASC, s.id ASC
                ) AS renewal_number
         FROM subscriptions s
       )
       SELECT r.id, r.member_id, m.member_number, m.member_code, m.full_name AS member_name,
               r.plan_id, COALESCE(r.plan_name, p.name) AS plan_name,
               COALESCE(r.duration_days, p.duration_days) AS duration_days,
               r.start_date, r.end_date,
              r.price, r.discount, r.final_price, r.status,
              r.freeze_start_date, r.freeze_end_date, r.freeze_reason,
              r.renewal_number
       FROM ranked r
       JOIN members m ON m.id = r.member_id
       JOIN membership_plans p ON p.id = r.plan_id
       WHERE r.renewal_number > 1
       ORDER BY r.start_date DESC, r.id DESC`)
        .all();
    const paymentRows = database
        .prepare(`SELECT p.id, p.member_id, p.subscription_id, m.member_number, m.member_code,
              m.full_name AS member_name,
              COALESCE(s.plan_name, pl.name) AS plan_name,
              (SELECT COUNT(*) FROM subscriptions earlier
               WHERE earlier.member_id = s.member_id
                 AND (earlier.start_date < s.start_date
                   OR (earlier.start_date = s.start_date AND earlier.id < s.id)))
                AS prior_subscriptions,
              p.amount, p.payment_method, p.payment_date, p.notes, p.created_at
       FROM payments p
       JOIN members m ON m.id = p.member_id
       LEFT JOIN subscriptions s ON s.id = p.subscription_id
       LEFT JOIN membership_plans pl ON pl.id = s.plan_id
       ORDER BY p.payment_date DESC, p.id DESC`)
        .all();
    const attendanceRowsAll = database
        .prepare(`SELECT a.id, a.member_id, m.member_number, m.member_code, m.full_name AS member_name,
              a.check_in_date, a.check_in_time, a.created_at
       FROM attendance a
       JOIN members m ON m.id = a.member_id
       ORDER BY a.check_in_date DESC, a.check_in_time DESC, a.id DESC`)
        .all();
    const expenseRows = database
        .prepare(`SELECT id, description, category, amount, payment_method, expense_date,
              expense_time, recorded_by, status, notes, created_at
       FROM expenses
       ORDER BY expense_date DESC, expense_time DESC, id DESC`)
        .all();
    const notificationRows = database
        .prepare(`SELECT id, type, title, message, severity, is_read, created_at
       FROM notifications
       ORDER BY created_at DESC, id DESC`)
        .all();
    const settingRows = database
        .prepare(`SELECT "key", value, value_type, updated_at
       FROM settings
       ORDER BY "key" ASC`)
        .all();
    const monthlyRevenueRows = database
        .prepare(`SELECT substr(payment_date, 1, 7) AS month,
              COALESCE(SUM(amount), 0) AS revenue
       FROM payments
       WHERE payment_date >= ?
       GROUP BY month`)
        .all(reportStart);
    const monthlyExpenseRows = database
        .prepare(`SELECT substr(expense_date, 1, 7) AS month,
              COALESCE(SUM(amount), 0) AS expenses
       FROM expenses
       WHERE expense_date >= ? AND status = 'active'
       GROUP BY month`)
        .all(reportStart);
    const monthlyMemberRows = database
        .prepare(`SELECT substr(registration_date, 1, 7) AS month,
              COUNT(*) AS new_members
       FROM members
       WHERE registration_date >= ?
       GROUP BY month`)
        .all(reportStart);
    const revenueByMonth = new Map(monthlyRevenueRows.map((row) => [row.month, Number(row.revenue)]));
    const expensesByMonth = new Map(monthlyExpenseRows.map((row) => [row.month, Number(row.expenses)]));
    const membersByMonth = new Map(monthlyMemberRows.map((row) => [row.month, Number(row.new_members)]));
    const monthlyReport = reportMonths.map((month) => ({
        month,
        revenue: revenueByMonth.get(month) ?? 0,
        expenses: expensesByMonth.get(month) ?? 0,
        newMembers: membersByMonth.get(month) ?? 0
    }));
    const paymentMethods = database
        .prepare(`SELECT payment_method AS method, COUNT(*) AS count,
              COALESCE(SUM(amount), 0) AS total
       FROM payments
       GROUP BY payment_method
       ORDER BY total DESC, method ASC`)
        .all();
    const expenseCategories = database
        .prepare(`SELECT category, COUNT(*) AS count, COALESCE(SUM(amount), 0) AS total
       FROM expenses
       WHERE status = 'active'
       GROUP BY category
       ORDER BY total DESC, category ASC`)
        .all();
    const membersResult = members.map((row) => ({
        id: row.id,
        memberCode: row.member_code,
        memberNumber: row.member_number,
        fullName: row.full_name,
        phone: row.phone,
        secondaryPhone: row.secondary_phone,
        address: row.address,
        gender: row.gender,
        dateOfBirth: row.date_of_birth,
        registrationDate: row.registration_date,
        emergencyContact: row.emergency_contact,
        notes: row.notes,
        status: row.status,
        photoData: row.photo_data,
        createdAt: row.created_at,
        updatedAt: row.updated_at
    }));
    const plans = planRows.map((row) => ({
        id: row.id,
        name: row.name,
        durationDays: row.duration_days,
        price: row.price,
        description: row.description,
        isActive: row.is_active === 1,
        activeSubscribers: Number(row.active_subscribers)
    }));
    const paidBySubscription = new Map();
    const paidRows = database
        .prepare(`SELECT subscription_id AS id, COALESCE(SUM(amount), 0) AS total
       FROM payments
       WHERE subscription_id IS NOT NULL
       GROUP BY subscription_id`)
        .all();
    for (const row of paidRows) {
        paidBySubscription.set(row.id, Number(row.total));
    }
    const subscriptions = subscriptionRows.map((row) => {
        const paidAmount = paidBySubscription.get(row.id) ?? 0;
        return {
            id: row.id,
            memberId: row.member_id,
            memberNumber: row.member_number,
            memberCode: row.member_code,
            memberName: row.member_name,
            planId: row.plan_id,
            planName: row.plan_name,
            durationDays: row.duration_days,
            startDate: row.start_date,
            endDate: row.end_date,
            price: row.price,
            discount: row.discount,
            finalPrice: row.final_price,
            status: row.status,
            paidAmount,
            balance: Math.max(0, row.final_price - paidAmount),
            freezeStartDate: row.freeze_start_date,
            freezeEndDate: row.freeze_end_date,
            freezeReason: row.freeze_reason
        };
    });
    const renewals = renewalRows.map((row) => {
        const paidAmount = paidBySubscription.get(row.id) ?? 0;
        return {
            id: row.id,
            memberId: row.member_id,
            memberNumber: row.member_number,
            memberCode: row.member_code,
            memberName: row.member_name,
            planId: row.plan_id,
            planName: row.plan_name,
            startDate: row.start_date,
            durationDays: row.duration_days,
            endDate: row.end_date,
            price: row.price,
            discount: row.discount,
            finalPrice: row.final_price,
            status: row.status,
            paidAmount,
            balance: Math.max(0, row.final_price - paidAmount),
            freezeStartDate: row.freeze_start_date,
            freezeEndDate: row.freeze_end_date,
            freezeReason: row.freeze_reason,
            renewalNumber: row.renewal_number
        };
    });
    const freezeRows = database
        .prepare(`SELECT id, subscription_id, start_date, end_date, reason, created_at
       FROM subscription_freezes
       ORDER BY start_date DESC, id DESC`)
        .all();
    const freezes = freezeRows.map((row) => ({
        id: row.id,
        subscriptionId: row.subscription_id,
        startDate: row.start_date,
        endDate: row.end_date,
        reason: row.reason,
        createdAt: row.created_at
    }));
    const payments = paymentRows.map((row) => ({
        id: row.id,
        memberId: row.member_id,
        memberNumber: row.member_number,
        subscriptionId: row.subscription_id,
        memberCode: row.member_code,
        memberName: row.member_name,
        planName: row.plan_name,
        paymentType: Number(row.prior_subscriptions ?? 0) > 0 ? 'renewal' : 'new',
        amount: row.amount,
        paymentMethod: row.payment_method,
        paymentDate: row.payment_date,
        notes: row.notes,
        createdAt: row.created_at
    }));
    const attendance = attendanceRowsAll.map((row) => ({
        id: row.id,
        memberId: row.member_id,
        memberNumber: row.member_number,
        memberCode: row.member_code,
        memberName: row.member_name,
        checkInDate: row.check_in_date,
        checkInTime: row.check_in_time,
        createdAt: row.created_at
    }));
    const expenses = expenseRows.map((row) => ({
        id: row.id,
        description: row.description,
        category: row.category,
        amount: row.amount,
        paymentMethod: row.payment_method,
        expenseDate: row.expense_date,
        expenseTime: row.expense_time,
        recordedBy: row.recorded_by,
        status: row.status,
        notes: row.notes,
        createdAt: row.created_at
    }));
    const notifications = notificationRows.map((row) => ({
        id: row.id,
        type: row.type,
        title: row.title,
        message: row.message,
        severity: row.severity,
        isRead: row.is_read === 1,
        createdAt: row.created_at
    }));
    const settings = settingRows.map((row) => ({
        key: row.key,
        value: row.value,
        valueType: row.value_type,
        updatedAt: row.updated_at
    }));
    const catalogRows = database
        .prepare(`SELECT key, name_ar, name_en, is_active, sort_order
       FROM expense_categories
       ORDER BY sort_order ASC, key ASC`)
        .all();
    const expenseCatalog = catalogRows.map((row) => ({
        key: row.key,
        nameAr: row.name_ar,
        nameEn: row.name_en,
        isActive: row.is_active === 1,
        sortOrder: row.sort_order
    }));
    return {
        generatedAt: (0, date_time_1.toUtcIsoTimestamp)(),
        totals,
        attendanceSeries,
        members: membersResult,
        memberStatusCounts,
        plans,
        subscriptions,
        renewals,
        freezes,
        payments,
        attendance,
        expenses,
        notifications,
        settings,
        expenseCatalog,
        monthlyReport,
        paymentMethods,
        expenseCategories
    };
}
//# sourceMappingURL=snapshot.js.map