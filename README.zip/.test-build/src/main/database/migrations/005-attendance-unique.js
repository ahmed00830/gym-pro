"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.attendanceUniqueMigration = void 0;
exports.attendanceUniqueMigration = {
    version: 5,
    name: 'attendance_unique_member_date',
    sql: `
CREATE UNIQUE INDEX IF NOT EXISTS idx_attendance_member_date_unique
  ON attendance (member_id, check_in_date);
`
};
//# sourceMappingURL=005-attendance-unique.js.map