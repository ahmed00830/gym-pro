"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LATEST_SCHEMA_VERSION = exports.MIGRATIONS = void 0;
const _001_core_schema_1 = require("./001-core-schema");
const _002_system_tables_1 = require("./002-system-tables");
const _003_member_photo_1 = require("./003-member-photo");
const _004_subscription_freezes_1 = require("./004-subscription-freezes");
const _005_attendance_unique_1 = require("./005-attendance-unique");
const _006_member_numbers_1 = require("./006-member-numbers");
const _007_subscription_history_snapshots_1 = require("./007-subscription-history-snapshots");
const _008_expenses_hardening_1 = require("./008-expenses-hardening");
const _009_expense_categories_1 = require("./009-expense-categories");
/**
 * Immutable, ordered database migrations. Never edit a migration that has
 * been released; add a new migration instead. The migration runner verifies a
 * SHA-256 checksum for every applied migration.
 */
exports.MIGRATIONS = Object.freeze([
    _001_core_schema_1.coreSchemaMigration,
    _002_system_tables_1.systemTablesMigration,
    _003_member_photo_1.memberPhotoMigration,
    _004_subscription_freezes_1.subscriptionFreezesMigration,
    _005_attendance_unique_1.attendanceUniqueMigration,
    _006_member_numbers_1.memberNumbersMigration,
    _007_subscription_history_snapshots_1.subscriptionHistorySnapshotsMigration,
    _008_expenses_hardening_1.expensesHardeningMigration,
    _009_expense_categories_1.expenseCategoriesMigration
]);
exports.LATEST_SCHEMA_VERSION = exports.MIGRATIONS[exports.MIGRATIONS.length - 1].version;
//# sourceMappingURL=index.js.map