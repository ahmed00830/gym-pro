"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createDatabaseConnection = createDatabaseConnection;
exports.getSchemaVersion = getSchemaVersion;
exports.getJournalMode = getJournalMode;
exports.getForeignKeysEnabled = getForeignKeysEnabled;
const better_sqlite3_1 = __importDefault(require("better-sqlite3"));
const node_fs_1 = require("node:fs");
const node_path_1 = require("node:path");
const BUSY_TIMEOUT_MS = 5_000;
/**
 * Opens and configures a SQLite connection for the GYM PRO main process.
 *
 * Foreign keys are enabled on every connection (they are a per-connection
 * SQLite setting), WAL provides reliable local concurrency, and a busy timeout
 * prevents transient lock failures. This function is never imported by the
 * renderer or preload layer.
 */
function createDatabaseConnection(filePath) {
    const absolutePath = (0, node_path_1.resolve)(filePath);
    (0, node_fs_1.mkdirSync)((0, node_path_1.dirname)(absolutePath), { recursive: true });
    const database = new better_sqlite3_1.default(absolutePath, {
        timeout: BUSY_TIMEOUT_MS
    });
    try {
        database.pragma('journal_mode = WAL');
        database.pragma('synchronous = NORMAL');
        database.pragma('foreign_keys = ON');
        database.pragma('busy_timeout = 5000');
        database.pragma('temp_store = MEMORY');
        database.pragma('cache_size = -8192');
        const foreignKeysEnabled = database.pragma('foreign_keys', {
            simple: true
        });
        if (foreignKeysEnabled !== 1) {
            throw new Error('SQLite foreign key enforcement could not be enabled.');
        }
        return database;
    }
    catch (error) {
        database.close();
        throw error;
    }
}
function getSchemaVersion(database) {
    return database.pragma('user_version', { simple: true });
}
function getJournalMode(database) {
    return database.pragma('journal_mode', { simple: true });
}
function getForeignKeysEnabled(database) {
    return database.pragma('foreign_keys', { simple: true }) === 1;
}
//# sourceMappingURL=connection.js.map