"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DATABASE_FILE_NAME = void 0;
exports.resolveDatabasePath = resolveDatabasePath;
exports.getDatabaseService = getDatabaseService;
exports.initializeDatabaseService = initializeDatabaseService;
exports.closeDatabaseService = closeDatabaseService;
const electron_1 = require("electron");
const node_path_1 = require("node:path");
const GymProDatabase_1 = require("./GymProDatabase");
exports.DATABASE_FILE_NAME = 'gym-pro.db';
let databaseService = null;
/**
 * Resolves the database inside Electron's per-user data directory. It must
 * never live beside the installed application, in the project source tree, or
 * in a directory writable by the renderer.
 */
function resolveDatabasePath(userDataPath = electron_1.app.getPath('userData')) {
    return (0, node_path_1.join)(userDataPath, exports.DATABASE_FILE_NAME);
}
function getDatabaseService() {
    if (!databaseService) {
        databaseService = new GymProDatabase_1.GymProDatabase(resolveDatabasePath());
    }
    return databaseService;
}
function initializeDatabaseService() {
    return getDatabaseService().initialize();
}
function closeDatabaseService() {
    databaseService?.close();
    databaseService = null;
}
//# sourceMappingURL=index.js.map